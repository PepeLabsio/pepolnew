export const SITE_URL =
  process.env.NODE_ENV === "production"
    ? "https://pepol-frontend.vercel.app"
    : "http://localhost:3000";

export const SITE_NAME = "Pepol";
export const SITE_TITLE = "Pepol";
export const SITE_DESCRIPTION =
  "PEPOL ON SOL";
